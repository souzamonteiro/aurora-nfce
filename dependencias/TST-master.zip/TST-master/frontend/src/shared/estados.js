export const EM_FILA = 1;
export const PROCESSAMENTO = 2;
export const PROCESSADO_COM_SUCESSO = 3;
export const PROCESSADO_COM_ERRO = 4;
export const ERRO = 5;
