//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.11 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2021.03.05 às 03:20:20 PM BRT 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.esocial.gov.br/servicos/empregador/consulta/identificadores-eventos/v1_0_0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.jus.esocialjt.comunicacao.wsdl;
