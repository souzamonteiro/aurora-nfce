//
// Este arquivo foi gerado pela Arquitetura JavaTM para Implementação de Referência (JAXB) de Bind XML, v2.2.8-b130911.1802 
// Consulte <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
// Gerado em: 2021.03.05 às 03:20:31 PM BRT 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.esocial.gov.br/schema/lote/eventos/envio/retornoEnvio/v1_1_0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.jus.esocialjt.comunicacao.lote.eventos.retorno.envio;
