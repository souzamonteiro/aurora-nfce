# esocial-cockpit (Descontinuado)

Atenção: esta versão do **esocial-cockpit** foi descontinuada em virtude do lançamento do [esocial-frontend](./frontend).

Caso necessite da versão anterior do esocial-cockpit, acesse a tag [cockpit-deprecation](https://github.com/tst-labs/esocial/tree/cockpit-deprecation)