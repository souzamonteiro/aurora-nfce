## Esta configuração foi incluída na documentação do projeto principal
