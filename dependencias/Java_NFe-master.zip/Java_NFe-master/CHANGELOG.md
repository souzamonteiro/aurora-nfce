# Notas de versão

- Atualizado Objeto e XSD NT 2023.001 1.20
- Adicionado Validacao XML Manual
