package br.com.swconsultoria.nfe.dom.enuns;

/**
 * @author Samuel Oliveira - samuk.exe@hotmail.com
 * Data: 02/03/2019 - 20:06
 */
public enum ConsultaDFeEnum {
    NSU,
    NSU_UNICO,
    CHAVE
}
