Texgit
======

[![Build Status](https://ci-jrimum.rhcloud.com/buildStatus/icon?job=Texgit)](https://ci-jrimum.rhcloud.com)

O projeto Texgit é um componente e framework em Java que facilita a manipulação de arquivos Flat Files (arquivo-texto) através de objetos.

Diversas empresas já usam o Texgit em produção e estão colaborando no Design do componente e da API.

