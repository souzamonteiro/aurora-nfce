Texgit Changelog
=============================

0.2.3 (2014/02/01) suport bopepo-0.2.3
---------------------------------------

**Improvement**

 * #1: Implementação de testes para funcionalidade LineOfFields
 
 
0.2.0-SNAPSHOT (2010/12/07) incubation 
---------------------------------------