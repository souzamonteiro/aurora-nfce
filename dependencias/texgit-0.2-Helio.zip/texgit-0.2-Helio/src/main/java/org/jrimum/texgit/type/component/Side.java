package org.jrimum.texgit.type.component;

/**
 * Lados para alinhar campos, preenchimento ou orientações em geral.
 * 
 * @author <a href="http://gilmatryx.googlepages.com/">Gilmar P.S.L.</a>
 */
public enum Side {

	LEFT,
	
	RIGHT;
}
