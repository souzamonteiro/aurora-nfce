package br.com.caelum.stella.validation;

public interface InvalidValue {

    String name();

}