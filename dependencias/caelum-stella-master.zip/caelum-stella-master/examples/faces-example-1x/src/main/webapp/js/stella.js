jQuery(function($){$(".cpf").mask("999.999.999-99");});
