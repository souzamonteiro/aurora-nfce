package br.com.caelum.stella.gateway.core;

public interface DefinedByCode {

	public String getCodigo();
}
