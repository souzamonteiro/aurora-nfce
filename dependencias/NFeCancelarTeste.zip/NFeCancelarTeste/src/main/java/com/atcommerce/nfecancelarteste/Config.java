/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.atcommerce.nfecancelarteste;

import br.com.swconsultoria.certificado.Certificado;
import br.com.swconsultoria.certificado.CertificadoService;
import br.com.swconsultoria.certificado.exception.CertificadoException;
import br.com.swconsultoria.nfe.dom.enuns.EstadosEnum;
import br.com.swconsultoria.nfe.dom.enuns.AmbienteEnum;
import br.com.swconsultoria.nfe.dom.ConfiguracoesNfe;
import br.com.swconsultoria.nfe.exception.NfeException;

/**
 *
 * @author roberto
 */
public class Config {
    private static Certificado certificadoA1Pfx() throws CertificadoException {
        try {
            String caminhoCertificado = "/home/roberto/certificados/33630582000149.pfx";
            String senha = "1234";

            return CertificadoService.certificadoPfx(caminhoCertificado, senha);
        } catch (Exception e)  {
            System.out.println("Erro: " + e);
            
            return null;
        }
    }
    
    public static ConfiguracoesNfe iniciaConfiguracoes() throws NfeException {
        try {
            Certificado certificado = certificadoA1Pfx();

            return ConfiguracoesNfe.criarConfiguracoes(EstadosEnum.BA , AmbienteEnum.HOMOLOGACAO,certificado, "/home/roberto/nfe/schemas");
        } catch (Exception e)  {
            System.out.println("Erro: " + e);
            
            return null;
        }
    }
    
    public static EstadosEnum getEstado() {
        return EstadosEnum.BA;
    }
}
