/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.bloco1;

import lombok.EqualsAndHashCode;

/**
 * @author Samuel Oliveira
 */
@EqualsAndHashCode
public class Registro1370 {

    private final String reg = "1370";
    private String num_bico;
    private String cod_item;
    private String num_tanque;

    /**
     * @return the num_bico
     */
    public String getNum_bico() {
        return num_bico;
    }

    /**
     * @param num_bico the num_bico to set
     */
    public void setNum_bico(String num_bico) {
        this.num_bico = num_bico;
    }

    /**
     * @return the cod_item
     */
    public String getCod_item() {
        return cod_item;
    }

    /**
     * @param cod_item the cod_item to set
     */
    public void setCod_item(String cod_item) {
        this.cod_item = cod_item;
    }

    /**
     * @return the num_tanque
     */
    public String getNum_tanque() {
        return num_tanque;
    }

    /**
     * @param num_tanque the num_tanque to set
     */
    public void setNum_tanque(String num_tanque) {
        this.num_tanque = num_tanque;
    }

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }

}
