/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.bloco0;

import lombok.EqualsAndHashCode;

/**
 * @author Samuel Oliveira
 *
 */
@EqualsAndHashCode
public class Registro0990 {

    private final String reg = "0990";
    private String qtd_lin_0;

    /**
     * @return the qtd_lin_0
     */
    public String getQtd_lin_0() {
        return qtd_lin_0;
    }

    /**
     * @param qtd_lin_0 the qtd_lin_0 to set
     */
    public void setQtd_lin_0(String qtd_lin_0) {
        this.qtd_lin_0 = qtd_lin_0;
    }

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }
}
