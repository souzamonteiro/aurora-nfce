/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.blocoD;

/**
 * @author Samuel Oliveira
 *
 */
public enum BlocoDEnum {

    RegistroD001,
    RegistroD100,
    RegistroD101,
    RegistroD110,
    RegistroD120,
    RegistroD130,
    RegistroD140,
    RegistroD150,
    RegistroD160,
    RegistroD161,
    RegistroD162,
    RegistroD170,
    RegistroD180,
    RegistroD190,
    RegistroD195,
    RegistroD197,
    RegistroD300,
    RegistroD301,
    RegistroD310,
    RegistroD350,
    RegistroD355,
    RegistroD360,
    RegistroD365,
    RegistroD370,
    RegistroD390,
    RegistroD400,
    RegistroD410,
    RegistroD411,
    RegistroD420,
    RegistroD500,
    RegistroD510,
    RegistroD530,
    RegistroD590,
    RegistroD600,
    RegistroD610,
    RegistroD690,
    RegistroD695,
    RegistroD696,
    RegistroD697,
    RegistroD700,
    RegistroD730,
    RegistroD731,
    RegistroD735,
    RegistroD737,
    RegistroD750,
    RegistroD760,
    RegistroD761,
    RegistroD990

}
