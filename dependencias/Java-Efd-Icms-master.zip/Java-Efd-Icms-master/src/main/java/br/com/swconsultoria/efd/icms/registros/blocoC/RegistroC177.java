/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.blocoC;

import lombok.EqualsAndHashCode;

/**
 * @author Samuel Oliveira
 *
 */
@EqualsAndHashCode
public class RegistroC177 {

    private final String reg = "C177";
    private String cod_selo_ipi;
    private String qt_selo_ipi;

    /**
     * @return the cod_selo_ipi
     */
    public String getCod_selo_ipi() {
        return cod_selo_ipi;
    }

    /**
     * @param cod_selo_ipi the cod_selo_ipi to set
     */
    public void setCod_selo_ipi(String cod_selo_ipi) {
        this.cod_selo_ipi = cod_selo_ipi;
    }

    /**
     * @return the qt_selo_ipi
     */
    public String getQt_selo_ipi() {
        return qt_selo_ipi;
    }

    /**
     * @param qt_selo_ipi the qt_selo_ipi to set
     */
    public void setQt_selo_ipi(String qt_selo_ipi) {
        this.qt_selo_ipi = qt_selo_ipi;
    }

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }

}
