/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.bloco1;

/**
 * @author Samuel Oliveira, Sidnei Klein
 *
 */
public enum Bloco1Enum {

    Registro1001,
    Registro1010,
    Registro1100,
    Registro1105,
    Registro1110,
    Registro1200,
    Registro1210,
    Registro1250,
    Registro1255,
    Registro1300,
    Registro1310,
    Registro1320,
    Registro1350,
    Registro1360,
    Registro1370,
    Registro1390,
    Registro1391,
    Registro1400,
    Registro1500,
    Registro1510,
    Registro1600,
    Registro1601,
    Registro1700,
    Registro1710,
    Registro1800,
    Registro1900,
    Registro1910,
    Registro1920,
    Registro1921,
    Registro1922,
    Registro1923,
    Registro1925,
    Registro1926,
    Registro1960, //add v3_0_1
    Registro1970, //add v3_0_1
    Registro1975, //add v3_0_1
    Registro1980, //add v3_0_1
    Registro1990

}
