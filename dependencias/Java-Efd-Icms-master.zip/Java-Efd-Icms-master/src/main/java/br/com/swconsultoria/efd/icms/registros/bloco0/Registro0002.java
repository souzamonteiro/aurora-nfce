/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.bloco0;

import lombok.EqualsAndHashCode;

/**
 * @author Samuel Oliveira
 *
 */
@EqualsAndHashCode
public class Registro0002 {

    private final String reg = "0002";
    private String class_estab_ind;

    public String getClass_estab_ind() {
        return class_estab_ind;
    }

    public void setClass_estab_ind(String class_estab_ind) {
        this.class_estab_ind = class_estab_ind;
    }

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }
}
