/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.blocoB;

/**
 * @author Sidnei Klein
 *
 */
public enum BlocoBEnum {

    RegistroB001, RegistroB020, RegistroB025, RegistroB030, RegistroB035, RegistroB350, RegistroB420, RegistroB440, RegistroB460, RegistroB470, RegistroB500, RegistroB510, RegistroB990

}
