/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.bloco0;

import lombok.EqualsAndHashCode;

/**
 * @author Samuel Oliveira
 *
 */
@EqualsAndHashCode
public class Registro0206 {

    private final String reg = "0206";
    private String cod_comb;

    /**
     * @return the cod_comb
     */
    public String getCod_comb() {
        return cod_comb;
    }

    /**
     * @param cod_comb the cod_comb to set
     */
    public void setCod_comb(String cod_comb) {
        this.cod_comb = cod_comb;
    }

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }
}
