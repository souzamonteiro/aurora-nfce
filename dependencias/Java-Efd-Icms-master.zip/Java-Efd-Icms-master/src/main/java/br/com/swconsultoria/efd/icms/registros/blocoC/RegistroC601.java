/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.blocoC;

import lombok.EqualsAndHashCode;

/**
 * @author Samuel Oliveira
 *
 */
@EqualsAndHashCode
public class RegistroC601 {

    private final String reg = "C601";
    private String num_doc_canc;

    /**
     * @return the num_doc_canc
     */
    public String getNum_doc_canc() {
        return num_doc_canc;
    }

    /**
     * @param num_doc_canc the num_doc_canc to set
     */
    public void setNum_doc_canc(String num_doc_canc) {
        this.num_doc_canc = num_doc_canc;
    }

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }

}
