/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.blocoC;

import lombok.EqualsAndHashCode;

/**
 * @author Samuel Oliveira
 *
 */
@EqualsAndHashCode
public class RegistroC470 {

    private final String reg = "C470";
    private String cod_item;
    private String qtd;
    private String qtd_canc;
    private String unid;
    private String vl_item;
    private String cst_icms;
    private String cfop;
    private String aliq_icms;
    private String vl_pis;
    private String vl_cofins;
    private RegistroC480 registroC480;

    public RegistroC480 getRegistroC480() {
        return registroC480;
    }

    public void setRegistroC480(RegistroC480 registroC480) {
        this.registroC480 = registroC480;
    }

    /**
     * @return the cod_item
     */
    public String getCod_item() {
        return cod_item;
    }

    /**
     * @param cod_item the cod_item to set
     */
    public void setCod_item(String cod_item) {
        this.cod_item = cod_item;
    }

    /**
     * @return the qtd
     */
    public String getQtd() {
        return qtd;
    }

    /**
     * @param qtd the qtd to set
     */
    public void setQtd(String qtd) {
        this.qtd = qtd;
    }

    /**
     * @return the qtd_canc
     */
    public String getQtd_canc() {
        return qtd_canc;
    }

    /**
     * @param qtd_canc the qtd_canc to set
     */
    public void setQtd_canc(String qtd_canc) {
        this.qtd_canc = qtd_canc;
    }

    /**
     * @return the unid
     */
    public String getUnid() {
        return unid;
    }

    /**
     * @param unid the unid to set
     */
    public void setUnid(String unid) {
        this.unid = unid;
    }

    /**
     * @return the vl_item
     */
    public String getVl_item() {
        return vl_item;
    }

    /**
     * @param vl_item the vl_item to set
     */
    public void setVl_item(String vl_item) {
        this.vl_item = vl_item;
    }

    /**
     * @return the cst_icms
     */
    public String getCst_icms() {
        return cst_icms;
    }

    /**
     * @param cst_icms the cst_icms to set
     */
    public void setCst_icms(String cst_icms) {
        this.cst_icms = cst_icms;
    }

    /**
     * @return the cfop
     */
    public String getCfop() {
        return cfop;
    }

    /**
     * @param cfop the cfop to set
     */
    public void setCfop(String cfop) {
        this.cfop = cfop;
    }

    /**
     * @return the aliq_icms
     */
    public String getAliq_icms() {
        return aliq_icms;
    }

    /**
     * @param aliq_icms the aliq_icms to set
     */
    public void setAliq_icms(String aliq_icms) {
        this.aliq_icms = aliq_icms;
    }

    /**
     * @return the vl_pis
     */
    public String getVl_pis() {
        return vl_pis;
    }

    /**
     * @param vl_pis the vl_pis to set
     */
    public void setVl_pis(String vl_pis) {
        this.vl_pis = vl_pis;
    }

    /**
     * @return the vl_cofins
     */
    public String getVl_cofins() {
        return vl_cofins;
    }

    /**
     * @param vl_cofins the vl_cofins to set
     */
    public void setVl_cofins(String vl_cofins) {
        this.vl_cofins = vl_cofins;
    }

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }

}
