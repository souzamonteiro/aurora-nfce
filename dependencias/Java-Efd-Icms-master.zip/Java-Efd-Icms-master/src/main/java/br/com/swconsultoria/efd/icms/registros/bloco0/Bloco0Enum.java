/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.bloco0;

/**
 * @author Samuel Oliveira
 */
public enum Bloco0Enum {

    Registro0000, Registro0001, Registro0002, Registro0005, Registro0015, Registro0100, Registro0150, Registro0175, Registro0190, Registro0200, Registro0205,
    Registro0206, Registro0210, Registro0220, Registro0221, Registro0300, Registro0305, Registro0400, Registro0450, Registro0460, Registro0500, Registro0600,
    Registro0990

}
