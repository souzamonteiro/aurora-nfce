/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.bloco1;

import lombok.EqualsAndHashCode;

/**
 * @author Sidnei Klein
 */
@EqualsAndHashCode
public class Registro1960 {

    private final String reg = "1960";
    private String ind_ap;
    private String g1_01;
    private String g1_02;
    private String g1_03;
    private String g1_04;
    private String g1_05;
    private String g1_06;
    private String g1_07;
    private String g1_08;
    private String g1_09;
    private String g1_10;
    private String g1_11;

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }

    /**
     * @return the ind_ap
     */
    public String getInd_ap() {
        return ind_ap;
    }

    /**
     * @param ind_ap the ind_ap to set
     */
    public void setInd_ap(String ind_ap) {
        this.ind_ap = ind_ap;
    }

    /**
     * @return the g1_01
     */
    public String getG1_01() {
        return g1_01;
    }

    /**
     * @param g1_01 the g1_01 to set
     */
    public void setG1_01(String g1_01) {
        this.g1_01 = g1_01;
    }

    /**
     * @return the g1_02
     */
    public String getG1_02() {
        return g1_02;
    }

    /**
     * @param g1_02 the g1_02 to set
     */
    public void setG1_02(String g1_02) {
        this.g1_02 = g1_02;
    }

    /**
     * @return the g1_03
     */
    public String getG1_03() {
        return g1_03;
    }

    /**
     * @param g1_03 the g1_03 to set
     */
    public void setG1_03(String g1_03) {
        this.g1_03 = g1_03;
    }

    /**
     * @return the g1_04
     */
    public String getG1_04() {
        return g1_04;
    }

    /**
     * @param g1_04 the g1_04 to set
     */
    public void setG1_04(String g1_04) {
        this.g1_04 = g1_04;
    }

    /**
     * @return the g1_05
     */
    public String getG1_05() {
        return g1_05;
    }

    /**
     * @param g1_05 the g1_05 to set
     */
    public void setG1_05(String g1_05) {
        this.g1_05 = g1_05;
    }

    /**
     * @return the g1_06
     */
    public String getG1_06() {
        return g1_06;
    }

    /**
     * @param g1_06 the g1_06 to set
     */
    public void setG1_06(String g1_06) {
        this.g1_06 = g1_06;
    }

    /**
     * @return the g1_07
     */
    public String getG1_07() {
        return g1_07;
    }

    /**
     * @param g1_07 the g1_07 to set
     */
    public void setG1_07(String g1_07) {
        this.g1_07 = g1_07;
    }

    /**
     * @return the g1_08
     */
    public String getG1_08() {
        return g1_08;
    }

    /**
     * @param g1_08 the g1_08 to set
     */
    public void setG1_08(String g1_08) {
        this.g1_08 = g1_08;
    }

    /**
     * @return the g1_09
     */
    public String getG1_09() {
        return g1_09;
    }

    /**
     * @param g1_09 the g1_09 to set
     */
    public void setG1_09(String g1_09) {
        this.g1_09 = g1_09;
    }

    /**
     * @return the g1_10
     */
    public String getG1_10() {
        return g1_10;
    }

    /**
     * @param g1_10 the g1_10 to set
     */
    public void setG1_10(String g1_10) {
        this.g1_10 = g1_10;
    }

    /**
     * @return the g1_11
     */
    public String getG1_11() {
        return g1_11;
    }

    /**
     * @param g1_11 the g1_11 to set
     */
    public void setG1_11(String g1_11) {
        this.g1_11 = g1_11;
    }

}
