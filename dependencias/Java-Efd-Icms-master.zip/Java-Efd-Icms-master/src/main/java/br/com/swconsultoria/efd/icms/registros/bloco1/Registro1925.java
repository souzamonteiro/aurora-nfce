/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.bloco1;

import lombok.EqualsAndHashCode;

/**
 * @author Samuel Oliveira
 */
@EqualsAndHashCode
public class Registro1925 {

    private final String reg = "1925";
    private String cod_inf_adic;
    private String vl_inf_adic;
    private String descr_compl_aj;

    /**
     * @return the cod_inf_adic
     */
    public String getCod_inf_adic() {
        return cod_inf_adic;
    }

    /**
     * @param cod_inf_adic the cod_inf_adic to set
     */
    public void setCod_inf_adic(String cod_inf_adic) {
        this.cod_inf_adic = cod_inf_adic;
    }

    /**
     * @return the vl_inf_adic
     */
    public String getVl_inf_adic() {
        return vl_inf_adic;
    }

    /**
     * @param vl_inf_adic the vl_inf_adic to set
     */
    public void setVl_inf_adic(String vl_inf_adic) {
        this.vl_inf_adic = vl_inf_adic;
    }

    /**
     * @return the descr_compl_aj
     */
    public String getDescr_compl_aj() {
        return descr_compl_aj;
    }

    /**
     * @param descr_compl_aj the descr_compl_aj to set
     */
    public void setDescr_compl_aj(String descr_compl_aj) {
        this.descr_compl_aj = descr_compl_aj;
    }

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }

}
