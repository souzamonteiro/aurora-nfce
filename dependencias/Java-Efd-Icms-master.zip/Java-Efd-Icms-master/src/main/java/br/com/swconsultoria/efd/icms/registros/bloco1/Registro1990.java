/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.bloco1;

import lombok.EqualsAndHashCode;

/**
 * @author Samuel Oliveira
 *
 */
@EqualsAndHashCode
public class Registro1990 {

    private final String reg = "1990";
    private String qtd_lin_1;

    /**
     * @return the qtd_lin_1
     */
    public String getQtd_lin_1() {
        return qtd_lin_1;
    }

    /**
     * @param qtd_lin_1 the qtd_lin_1 to set
     */
    public void setQtd_lin_1(String qtd_lin_1) {
        this.qtd_lin_1 = qtd_lin_1;
    }

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }
}
