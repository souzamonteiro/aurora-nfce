/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.bloco9;

import lombok.EqualsAndHashCode;

/**
 * @author Samuel Oliveira
 *
 */
@EqualsAndHashCode
public class Registro9990 {

    private final String reg = "9990";
    private String qtd_lin_9;

    /**
     * @return the qtd_lin_9
     */
    public String getQtd_lin_9() {
        return qtd_lin_9;
    }

    /**
     * @param qtd_lin_9 the qtd_lin_9 to set
     */
    public void setQtd_lin_9(String qtd_lin_9) {
        this.qtd_lin_9 = qtd_lin_9;
    }

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }
}
