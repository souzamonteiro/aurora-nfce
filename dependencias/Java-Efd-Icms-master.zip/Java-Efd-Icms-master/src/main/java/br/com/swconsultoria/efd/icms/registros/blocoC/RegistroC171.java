/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.blocoC;

import lombok.EqualsAndHashCode;

/**
 * @author Samuel Oliveira
 *
 */
@EqualsAndHashCode
public class RegistroC171 {

    private final String reg = "C171";
    private String num_tanque;
    private String qtde;

    /**
     * @return the num_tanque
     */
    public String getNum_tanque() {
        return num_tanque;
    }

    /**
     * @param num_tanque the num_tanque to set
     */
    public void setNum_tanque(String num_tanque) {
        this.num_tanque = num_tanque;
    }

    /**
     * @return the qtde
     */
    public String getQtde() {
        return qtde;
    }

    /**
     * @param qtde the qtde to set
     */
    public void setQtde(String qtde) {
        this.qtde = qtde;
    }

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }

}
