/**
 *
 */
package br.com.swconsultoria.efd.icms.registros.bloco1;

import lombok.EqualsAndHashCode;

/**
 * @author Samuel Oliveira
 */
@EqualsAndHashCode
public class Registro1360 {

    private final String reg = "1360";
    private String num_lacre;
    private String dt_aplicacao;

    /**
     * @return the num_lacre
     */
    public String getNum_lacre() {
        return num_lacre;
    }

    /**
     * @param num_lacre the num_lacre to set
     */
    public void setNum_lacre(String num_lacre) {
        this.num_lacre = num_lacre;
    }

    /**
     * @return the dt_aplicacao
     */
    public String getDt_aplicacao() {
        return dt_aplicacao;
    }

    /**
     * @param dt_aplicacao the dt_aplicacao to set
     */
    public void setDt_aplicacao(String dt_aplicacao) {
        this.dt_aplicacao = dt_aplicacao;
    }

    /**
     * @return the reg
     */
    public String getReg() {
        return reg;
    }

}
