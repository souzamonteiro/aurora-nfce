package br.com.swconsultoria.cte.dom.enuns;

/**
 * @author Samuel Oliveira - samuk.exe@hotmail.com
 * Data: 02/03/2019 - 20:04
 */
public enum PessoaEnum {
    FISICA,
    JURIDICA
}
