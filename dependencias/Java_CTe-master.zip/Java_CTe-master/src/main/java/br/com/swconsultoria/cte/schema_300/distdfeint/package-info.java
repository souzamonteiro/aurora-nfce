@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.portalfiscal.inf.br/cte", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.com.swconsultoria.cte.schema_300.distdfeint;
