Domkee
======

[![Build Status](https://ci-jrimum.rhcloud.com/buildStatus/icon?job=Domkee)](https://ci-jrimum.rhcloud.com)

Objetos de domínio usados no projeto [Lançado embutido, incubado]
