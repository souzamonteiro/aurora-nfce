package com.fincatto.documentofiscal.mdfe3.classes.nota.evento;

import org.simpleframework.xml.Root;

/**
 * Created by Eldevan Nery Junior on 17/11/17.
 */
@Root(name = "retCancMDFe")
public class MDFeRetornoEncerramento extends MDFeRetorno {
    private static final long serialVersionUID = 5542869506015237818L;

}
