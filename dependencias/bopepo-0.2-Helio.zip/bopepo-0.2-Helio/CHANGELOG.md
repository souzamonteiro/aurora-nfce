Bopepo Changelog
====================================================

0.2.3 (2014/02/01) main release GitHub
----------------------------------------------------------------------

**Improvement**

 * #1: Mudar passagem de parâmetros bancários de string para enum
 * #2: Colocar complemento do endereço do sacado como campo padrão no boleto
 * #4: Novo Banco: BRB
 * #5: Novo enum com todos os campos padrões do boleto
 * #6: Atualizar templates dos boletos em função da nova nomenclatura BACEN
 * #7: Substituir funções de texto do utilix por similar em texgit
 * #8: Inserir meta-dados realcionados ao PDF
 * #9: Campos formatados em função do padrão de cada Banco
 * #11: Novo Banco: CECRED


0.2.3-SNAPSHOT (2011-02-09) TracSVN
----------------------------------------------------------------------

**Fix**

 * #25: Implementação BANCO SANTANDER S.A. - Correção do uso de dígitos verificadores.
 * #13: Banco Real - Mudança do número do documento pelo nosso número

**Improvement**

 * #54: Implementação Campo Livre SICOB - CEF
 * #58: Bancoob
 * Novas formas de processamento em lote
 * Novas formas para definição de template
 * Opção de definição de compressão do PDF
 * Classe para geração isolada de código de barras
 * Classe para geração de pdfs estilo relatório
 

0.3-Litio-GeracaoGuia-VersaoAvaliacao-2011-04-14 (2011/04/14) TracSVN
----------------------------------------------------------------------

 * Ajustes construtores de OrgaoRecebedor e Arrecadacao, que sofreram ajustes básicos nos parâmetros.   
 * Novo exemplo MinhaPrimeiraGuiaASerPagaEmVariosBancos.


0.2.3-SNAPSHOT (2011-02-09) TracSVN
----------------------------------------------------------------------

**Improvement**

 * Novo Banco: Banco do Nordeste
 * Novo Boleto: Banco do Brasil convênio 7 dígitos nosso número 17 dígitos.


0.3-Litio-GeracaoGuia-VersaoAvaliacao-2010-09-17 (2010/09/17) TracSVN
----------------------------------------------------------------------

0.3-Litio-GeracaoGuia-VersaoAvaliacao-2010-09-09 (2010/09/09) TracSVN
----------------------------------------------------------------------

0.3-Litio-GeracaoGuia-VersaoAvaliacao-2010-06-10 (2010/06/10) TracSVN
----------------------------------------------------------------------

0.2.2 (2009/10/18) main release TracSVN
----------------------------------------------------------------------

0.2.1-INC2X (2008/11/13) incubation TracSVN
----------------------------------------------------------------------

0.2.1-INC2 (2008/07/15) incubation TracSVN
----------------------------------------------------------------------
   
0.2.1-INC (2008/06/15) incubation TracSVN
----------------------------------------------------------------------
  