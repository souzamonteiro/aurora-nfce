Bopepo
======

[![Build Status](https://ci-jrimum.rhcloud.com/buildStatus/icon?job=Bopepo)](https://ci-jrimum.rhcloud.com)

Biblioteca Java para geração de boletos bancários.

 * http://jrimum.org/bopepo 
