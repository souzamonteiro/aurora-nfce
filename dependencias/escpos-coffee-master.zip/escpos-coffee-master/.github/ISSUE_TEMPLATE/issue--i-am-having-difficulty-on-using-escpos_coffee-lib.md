---
name: 'Issue: I am having difficulty on using escpos_coffee lib'
about: You have problems while using the lib
title: ''
labels: help wanted, question
assignees: ''

---

<!-- before open the issue, you can try to solve with

     If you are looking for support, please check out our wiki
     or  take a look at https://github.com/anastaciocintra/escpos-coffee-samples
-->

## Steps to Reproduce

<!-- Please tell us exactly how to reproduce the problem you are running into. -->

1. ...
2. ...
3. ...


<!-- If necessary, paste the piece of code to simulate the problem -->

```
```

## Evidences

<!--
      If necessary, put pictures of the printed paper
-->
