/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.souzamonteiro.escposteste;

import javax.print.PrintService;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Locale;

import com.github.anastaciocintra.escpos.barcode.QRCode;
import com.github.anastaciocintra.escpos.EscPos;
import com.github.anastaciocintra.escpos.EscPosConst;
import com.github.anastaciocintra.escpos.EscPos.CharacterCodeTable;
import com.github.anastaciocintra.escpos.Style;
import com.github.anastaciocintra.output.PrinterOutputStream;

import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author roberto
 */
public class ESCPOSTeste {

    public static void main(String[] args) {
        try {
            PrintService printService = PrinterOutputStream.getPrintServiceByName("MiniThermalPrinter");
            PrinterOutputStream printerOutputStream = new PrinterOutputStream(printService);
            EscPos escpos = new EscPos(printerOutputStream);
            
            // 0         1         2         3
            // 0123456789012345678901234567890
            // -------------------------------
            //       CNPJ: 33630582000149
            // Editora Roberto Luiz Souza Mont
            //               eiro
            // Rua Chile, s/n, Edifício Eduard
            //      o De Moraes, sala 606
            //      Centro, Salvador, BA
            //   Documento Auxiliar da Nota
            // Fiscal de Consumidor Eletrônica
            // -------------------------------
            // Código|Descrição
            //    Qtde|UN |  Vl Unit| Vl Total
            // 001|Banqueta plástica dobrável,
            //     branca, altura 220 mm
            //    1,00|PC |    56,08|    56,08
            // 002|Jogo de cinta com catraca p
            //     ara amarração de carga 0,8
            //     tf/0,4 tf, CC 080
            //    1,00|PC |    37,82|    75,64
            // 003|Óleo de cambio manual SAE 8
            //     0 W Flex Oil 1Lt
            //    1,00|UN |    13,00|    13,00
            // -------------------------------
            //                     12345678901
            // Qtde. total de itens          3
            //               12345678901234567
            // Valor total R$           144,72
            //            12345678901234567890
            // Desconto R$                1,30
            //                 123456789012345
            // Valor a Pagar R$         143,42
            // FORMA PAGAMENTO   VALOR PAGO R$
            //         12345678901234567890123
            // Dinheiro                  50,00
            //                  12345678901234
            // Cartão de Crédito         40,00
            //                 123456789012345
            // Cartão de Débito         100,00
            //         12345678901234567890123
            // Troco R$                  46,58
            // -------------------------------
            //  Consulte pela Chave de Acesso
            //  em https://sistemas.sefaz.am.g
            //  ov.br/nfceweb-hom/formConsulta
            //  .do
            //  1323 0533 6305 8200 0149 6500
            //    1000 0003 1810 0000 3193
            // -------------------------------
            // CONSUMIDOR - CPF: 40325635862 -
            //     Andréia Rita da Silva
            // -------------------------------
            //    NFC-e n.: 318 Série: 1
            //     2023-05-19 08:24:28
            //
            //  Protocolo de autorização:
            //       113230010671996
            //     Data de autorização:
            //     2023-05-19 07:24:33
            //
            //    EMITIDA EM AMBIENTE DE
            // HOMOLOGAÇÃO - SEM VALOR FISCAL
            //
            //        +--------------+
            //        |              |
            //        |              |
            //        |              |
            //        |              |
            //        |              |
            //        |              |
            //        +--------------+
            //
            // -------------------------------
            // Tributos Totais Incidentes (Lei
            //  Federal 12.741/2012): R$73,27.
            //  Trib aprox R$: 46,68 Fed, 26,5
            // 9 Est e 0,00 Mun. Fonte: IBPT.
            
            // Inicializa a impressora.
            escpos.initializePrinter();
            // Seleciona a página de código Latin-1.
            escpos.setPrinterCharacterTable(3);
            
            NumberFormat numberFormat = NumberFormat.getNumberInstance(new Locale("pt", "BR"));
            numberFormat.setMinimumFractionDigits(2);
            numberFormat.setMaximumFractionDigits(2);
            
            //escpos.writeLF("0         1         2         3");
            //escpos.writeLF("0123456789012345678901234567890");
            escpos.writeLF(StringUtils.center("CNPJ: 33630582000149", 31));
            escpos.writeLF(StringUtils.abbreviate("Editora Roberto Luiz Souza Mont", 31));
            escpos.writeLF(StringUtils.center("Rua Chile, s/n, ", 31));
            escpos.writeLF(StringUtils.center("Edifício Eduardo De Moraes, sala 606", 31));
            escpos.writeLF(StringUtils.center("Centro, Salvador, BA", 31));
            escpos.writeLF(StringUtils.center("Documento Auxiliar da Nota", 31));
            escpos.writeLF(StringUtils.center("Fiscal de Consumidor Eletrônica", 31));
            escpos.writeLF("-------------------------------");
            escpos.writeLF("Código|Descrição");
            escpos.writeLF("   Qtde|UN |  Vl Unit| Vl Total");
            escpos.writeLF(StringUtils.leftPad("1", 3, "0") + "|" + StringUtils.abbreviate("Banqueta plástica dobrável, branca, altura 220 mm", 27));
            escpos.writeLF(StringUtils.leftPad(numberFormat.format(Float.parseFloat("1.00")), 7) + "|" + StringUtils.rightPad("PC", 3) + "|" + StringUtils.leftPad("56,08", 9) + "|" + StringUtils.leftPad("56,08", 9));
            escpos.writeLF(StringUtils.leftPad("2", 3, "0") + "|" + StringUtils.abbreviate("Jogo de cinta com catraca para amarração de carga 0,8 tf/0,4 tf, CC 080", 27));
            escpos.writeLF(StringUtils.leftPad("1,00", 7) + "|" + StringUtils.rightPad("PC", 3) + "|" + StringUtils.leftPad("37,82", 9) + "|" + StringUtils.leftPad("75,64", 9));
            escpos.writeLF(StringUtils.leftPad("3", 3, "0") + "|" + StringUtils.abbreviate("Óleo de cambio manual SAE 80W Flex Oil 1Lt", 27));
            escpos.writeLF(StringUtils.leftPad("1,00", 7) + "|" + StringUtils.rightPad("UN", 3) + "|" + StringUtils.leftPad("13,00", 9) + "|" + StringUtils.leftPad("13,00", 9));
            escpos.writeLF("-------------------------------");
            escpos.writeLF("Qtde. total de itens" + StringUtils.leftPad("3", 11));
            escpos.writeLF("Valor total R$" + StringUtils.leftPad("144,72", 17));
            escpos.writeLF("Desconto R$" + StringUtils.leftPad("1,30", 20));
            escpos.writeLF("Valor a Pagar R$" + StringUtils.leftPad("143,42", 15));;
            escpos.writeLF("FORMA PAGAMENTO   VALOR PAGO R$");
            escpos.writeLF("Dinheiro" + StringUtils.leftPad("50,00", 23));
            escpos.writeLF("Cartão de Crédito" + StringUtils.leftPad("40,00", 14));
            escpos.writeLF("Cartão de Débito" + StringUtils.leftPad("100,00", 15));
            escpos.writeLF("Troco R$" + StringUtils.leftPad("46,58", 23));
            escpos.writeLF("-------------------------------");
            escpos.writeLF(StringUtils.center("Consulte pela Chave de Acesso em https://sistemas.sefaz.am.gov.br/nfceweb-hom/formConsulta.do", 31));
            escpos.writeLF(StringUtils.center(" 1323 0533 6305 8200 0149 6500", 31));
            escpos.writeLF(StringUtils.center("1000 0003 1810 0000 3193", 31));
            escpos.writeLF("-------------------------------");
            escpos.writeLF(StringUtils.center("CONSUMIDOR - CPF: 40325635862 - Andréia Rita da Silva", 31));
            escpos.writeLF("-------------------------------");
            escpos.writeLF(StringUtils.center("NFC-e n.: 318 Série: 1", 31));
            escpos.writeLF(StringUtils.center("2023-05-19 08:24:28", 31));
            escpos.writeLF("");
            escpos.writeLF(StringUtils.center("Protocolo de autorização:", 31));
            escpos.writeLF(StringUtils.center("113230010671996", 31));
            escpos.writeLF(StringUtils.center("Data de autorização:", 31));
            escpos.writeLF(StringUtils.center("2023-05-19 07:24:33", 31));
            escpos.writeLF("");
            escpos.writeLF(StringUtils.center("EMITIDA EM AMBIENTE DE", 31));
            escpos.writeLF(StringUtils.center("HOMOLOGAÇÃO - SEM VALOR FISCAL", 31));
            escpos.writeLF("");
            /*
            escpos.writeLF("       +--------------+");
            escpos.writeLF("       |              |");
            escpos.writeLF("       |              |");
            escpos.writeLF("       |              |");
            escpos.writeLF("       |              |");
            escpos.writeLF("       |              |");
            escpos.writeLF("       |              |");
            escpos.writeLF("       +--------------+");
            */
            
            QRCode qrcode = new QRCode();
            qrcode.setSize(6);
            qrcode.setJustification(EscPosConst.Justification.Center);
            escpos.write(qrcode, "https://sistemas.sefaz.am.gov.br/nfceweb-hom/consultarNFCe.jsp?p=13230533630582000149650010000003181000003193|2|2|1|E3614A1EE77FA0A15D238F69DC20F184B9133555");
            
            escpos.writeLF("-------------------------------");
            escpos.writeLF("Tributos Totais Incidentes (Lei");
            escpos.writeLF(" Federal 12.741/2012): R$73,27.");
            escpos.writeLF(" Trib aprox R$: 46,68 Fed, 26,5");
            escpos.writeLF("9 Est e 0,00 Mun. Fonte: IBPT.");
            
            escpos.feed(5).cut(EscPos.CutMode.FULL);
            escpos.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
