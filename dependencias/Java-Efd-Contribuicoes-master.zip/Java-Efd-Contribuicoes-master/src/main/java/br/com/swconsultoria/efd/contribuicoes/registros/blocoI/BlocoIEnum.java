/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.blocoI;

/**
 * @author Yuri Lemes
 *
 */
public enum BlocoIEnum {

	RegistroI001,
	RegistroI010,
	RegistroI100,
	RegistroI199,
	RegistroI200,
	RegistroI299,
	RegistroI300,
	RegistroI399,
	RegistroI990
	
}
