/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.blocoA;

/**
 * @author Yuri Lemes
 *
 */
public enum BlocoAEnum {

	RegistroA001,
	RegistroA010,
	RegistroA100,
	RegistroA110,
	RegistroA111,
	RegistroA120,
	RegistroA170,
	RegistroA990
	
}
