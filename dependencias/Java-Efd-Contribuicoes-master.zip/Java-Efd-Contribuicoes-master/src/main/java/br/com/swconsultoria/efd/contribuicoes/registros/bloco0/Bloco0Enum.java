/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.bloco0;

/**
 * @author Yuri Lemes
 *
 */
public enum Bloco0Enum {

	Registro0000,
	Registro0001,
	Registro0035,
	Registro0100,
	Registro0110,
	Registro0111,
	Registro0120,
	Registro0140,
	Registro0145,
	Registro0150,
	Registro0190,
	Registro0200,
	Registro0205,
	Registro0206,
	Registro0208,
	Registro0400,
	Registro0450,
	Registro0500,
	Registro0600,
	Registro0900,
	Registro0990
	
}
