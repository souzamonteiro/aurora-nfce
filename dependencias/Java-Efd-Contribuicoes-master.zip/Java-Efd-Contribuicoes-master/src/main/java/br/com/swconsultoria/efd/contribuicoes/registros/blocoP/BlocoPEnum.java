/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.blocoP;

/**
 * @author Yuri Lemes
 *
 */
public enum BlocoPEnum {

	RegistroP001,
	RegistroP010,
	RegistroP100,
	RegistroP110,
	RegistroP199,
	RegistroP200,
	RegistroP210,
	RegistroP990
	
}
