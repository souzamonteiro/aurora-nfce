/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.bloco1;

/**
 * @author Yuri Lemes
 *
 */
public enum Bloco1Enum {

	Registro1001,
	Registro1010,
	Registro1011,
	Registro1020,
	Registro1050,
	Registro1100,
	Registro1101,
	Registro1102,
	Registro1200,
	Registro1210,
	Registro1220,
	Registro1300,
	Registro1500,
	Registro1501,
	Registro1502,
	Registro1600,
	Registro1610,
	Registro1620,
	Registro1700,
	Registro1800,
	Registro1809,
	Registro1900,
	Registro1990
	
}
