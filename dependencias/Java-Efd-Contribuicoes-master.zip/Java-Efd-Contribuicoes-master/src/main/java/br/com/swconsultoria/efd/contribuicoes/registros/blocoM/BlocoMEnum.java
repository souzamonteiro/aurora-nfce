/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.blocoM;

/**
 * @author Yuri Lemes
 *
 */
public enum BlocoMEnum {

	RegistroM001,
	RegistroM100,
	RegistroM105,
	RegistroM110,
	RegistroM115,
	RegistroM200,
	RegistroM205,
	RegistroM210,
	RegistroM211,
	RegistroM215,
	RegistroM220,
	RegistroM225,
	RegistroM230,
	RegistroM300,
	RegistroM350,
	RegistroM400,
	RegistroM410,
	RegistroM500,
	RegistroM505,
	RegistroM510,
	RegistroM515,
	RegistroM600,
	RegistroM605,
	RegistroM610,
	RegistroM611,
	RegistroM615,
	RegistroM620,
	RegistroM625,
	RegistroM630,
	RegistroM700,
	RegistroM800,
	RegistroM810,
	RegistroM990
	
}
