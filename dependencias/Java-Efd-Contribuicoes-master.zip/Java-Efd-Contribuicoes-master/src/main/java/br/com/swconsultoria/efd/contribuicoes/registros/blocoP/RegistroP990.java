/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.blocoP;

/**
 * @author Yuri Lemes
 *
 */
public class RegistroP990 {

	private final String reg = "P990";
	private String qtd_lin_p;

	/**
	 * @return the qtd_lin_p
	 */
	public String getQtd_lin_p() {
		return qtd_lin_p;
	}

	/**
	 * @param qtd_lin_p
	 *            the qtd_lin_p to set
	 */
	public void setQtd_lin_p(String qtd_lin_p) {
		this.qtd_lin_p = qtd_lin_p;
	}

	/**
	 * @return the reg
	 */
	public String getReg() {
		return reg;
	}

}
