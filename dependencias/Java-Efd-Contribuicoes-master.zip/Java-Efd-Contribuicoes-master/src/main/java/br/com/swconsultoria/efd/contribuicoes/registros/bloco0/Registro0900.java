/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.bloco0;

/**
 * @author Yuri Lemes
 *
 */
public class Registro0900 {

	private final String reg = "0900";
	private String rec_total_bloco_a;
	private String rec_nrb_bloco_a;
	private String rec_total_bloco_c;
	private String rec_nrb_bloco_c;
	private String rec_total_bloco_d;
	private String rec_nrb_bloco_d;
	private String rec_total_bloco_f;
	private String rec_nrb_bloco_f;
	private String rec_total_bloco_i;
	private String rec_nrb_bloco_i;
	private String rec_total_bloco_1;
	private String rec_nrb_bloco_1;
	private String rec_total_periodo;
	private String rec_total_nrb_periodo;

	/**
	 * @return the reg
	 */
	public String getReg() {
		return reg;
	}

	public String getRec_total_bloco_a() {
		return rec_total_bloco_a;
	}

	public void setRec_total_bloco_a(String rec_total_bloco_a) {
		this.rec_total_bloco_a = rec_total_bloco_a;
	}

	public String getRec_nrb_bloco_a() {
		return rec_nrb_bloco_a;
	}

	public void setRec_nrb_bloco_a(String rec_nrb_bloco_a) {
		this.rec_nrb_bloco_a = rec_nrb_bloco_a;
	}

	public String getRec_total_bloco_c() {
		return rec_total_bloco_c;
	}

	public void setRec_total_bloco_c(String rec_total_bloco_c) {
		this.rec_total_bloco_c = rec_total_bloco_c;
	}

	public String getRec_nrb_bloco_c() {
		return rec_nrb_bloco_c;
	}

	public void setRec_nrb_bloco_c(String rec_nrb_bloco_c) {
		this.rec_nrb_bloco_c = rec_nrb_bloco_c;
	}

	public String getRec_total_bloco_d() {
		return rec_total_bloco_d;
	}

	public void setRec_total_bloco_d(String rec_total_bloco_d) {
		this.rec_total_bloco_d = rec_total_bloco_d;
	}

	public String getRec_nrb_bloco_d() {
		return rec_nrb_bloco_d;
	}

	public void setRec_nrb_bloco_d(String rec_nrb_bloco_d) {
		this.rec_nrb_bloco_d = rec_nrb_bloco_d;
	}

	public String getRec_total_bloco_f() {
		return rec_total_bloco_f;
	}

	public void setRec_total_bloco_f(String rec_total_bloco_f) {
		this.rec_total_bloco_f = rec_total_bloco_f;
	}

	public String getRec_nrb_bloco_f() {
		return rec_nrb_bloco_f;
	}

	public void setRec_nrb_bloco_f(String rec_nrb_bloco_f) {
		this.rec_nrb_bloco_f = rec_nrb_bloco_f;
	}

	public String getRec_total_bloco_i() {
		return rec_total_bloco_i;
	}

	public void setRec_total_bloco_i(String rec_total_bloco_i) {
		this.rec_total_bloco_i = rec_total_bloco_i;
	}

	public String getRec_nrb_bloco_i() {
		return rec_nrb_bloco_i;
	}

	public void setRec_nrb_bloco_i(String rec_nrb_bloco_i) {
		this.rec_nrb_bloco_i = rec_nrb_bloco_i;
	}

	public String getRec_total_bloco_1() {
		return rec_total_bloco_1;
	}

	public void setRec_total_bloco_1(String rec_total_bloco_1) {
		this.rec_total_bloco_1 = rec_total_bloco_1;
	}

	public String getRec_nrb_bloco_1() {
		return rec_nrb_bloco_1;
	}

	public void setRec_nrb_bloco_1(String rec_nrb_bloco_1) {
		this.rec_nrb_bloco_1 = rec_nrb_bloco_1;
	}

	public String getRec_total_periodo() {
		return rec_total_periodo;
	}

	public void setRec_total_periodo(String rec_total_periodo) {
		this.rec_total_periodo = rec_total_periodo;
	}

	public String getRec_total_nrb_periodo() {
		return rec_total_nrb_periodo;
	}

	public void setRec_total_nrb_periodo(String rec_total_nrb_periodo) {
		this.rec_total_nrb_periodo = rec_total_nrb_periodo;
	}
}
