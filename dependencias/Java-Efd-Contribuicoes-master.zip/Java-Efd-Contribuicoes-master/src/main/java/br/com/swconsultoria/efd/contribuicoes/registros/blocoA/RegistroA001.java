/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.blocoA;

/**
 * @author Yuri Lemes
 *
 */
public class RegistroA001 {

	private final String reg = "A001";
	private String ind_mov;

	public String getInd_mov() {
		return ind_mov;
	}

	public void setInd_mov(String ind_mov) {
		this.ind_mov = ind_mov;
	}

	public String getReg() {
		return reg;
	}

}
