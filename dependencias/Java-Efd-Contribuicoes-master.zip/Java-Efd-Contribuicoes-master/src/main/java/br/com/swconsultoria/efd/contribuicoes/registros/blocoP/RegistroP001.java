/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.blocoP;
/**
 * @author Yuri Lemes
 *
 */
public class RegistroP001 {

	private final String reg = "P001";
	private String ind_mov;

	/**
	 * @return the reg
	 */
	public String getReg() {
		return reg;
	}

	/**
	 * @return the ind_mov
	 */
	public String getInd_mov() {
		return ind_mov;
	}

	/**
	 * @param ind_mov
	 *            the ind_mov to set
	 */
	public void setInd_mov(String ind_mov) {
		this.ind_mov = ind_mov;
	}
}
