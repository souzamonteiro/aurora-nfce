/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.blocoA;

/**
 * @author Yuri Lemes
 *
 */
public class RegistroA990 {

	private final String reg = "A990";
	private String qtd_lin_a;

	/**
	 * @return the qtd_lin_a
	 */
	public String getQtd_lin_a() {
		return qtd_lin_a;
	}

	/**
	 * @param qtd_lin_a
	 *            the qtd_lin_a to set
	 */
	public void setQtd_lin_a(String qtd_lin_a) {
		this.qtd_lin_a = qtd_lin_a;
	}

	/**
	 * @return the reg
	 */
	public String getReg() {
		return reg;
	}

}
