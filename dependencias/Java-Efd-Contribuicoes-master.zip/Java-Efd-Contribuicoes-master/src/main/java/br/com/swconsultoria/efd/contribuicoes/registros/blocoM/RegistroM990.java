/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.blocoM;

/**
 * @author Yuri Lemes
 *
 */
public class RegistroM990 {

	private final String reg = "M990";
	private String qtd_lin_m;

	/**
	 * @return the qtd_lin_m
	 */
	public String getQtd_lin_m() {
		return qtd_lin_m;
	}

	/**
	 * @param qtd_lin_m
	 *            the qtd_lin_m to set
	 */
	public void setQtd_lin_m(String qtd_lin_m) {
		this.qtd_lin_m = qtd_lin_m;
	}

	/**
	 * @return the reg
	 */
	public String getReg() {
		return reg;
	}

}
