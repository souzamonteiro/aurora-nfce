/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.blocoD;

/**
 * @author Yuri Lemes
 *
 */
public enum BlocoDEnum {

	RegistroD001,
	RegistroD010,
	RegistroD100,
	RegistroD101,
	RegistroD105,
	RegistroD111,
	RegistroD200,
	RegistroD201,
	RegistroD205,
	RegistroD209,
	RegistroD300,
	RegistroD309,
	RegistroD350,
	RegistroD359,
	RegistroD500,
	RegistroD501,
	RegistroD505,
	RegistroD509,
	RegistroD600,
	RegistroD601,
	RegistroD605,
	RegistroD609,
	RegistroD990
	
}
