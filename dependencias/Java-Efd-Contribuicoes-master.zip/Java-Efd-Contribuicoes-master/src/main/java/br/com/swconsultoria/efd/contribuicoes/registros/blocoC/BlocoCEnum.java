/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.blocoC;

/**
 * @author Yuri Lemes
 *
 */
public enum BlocoCEnum {

	RegistroC001,
	RegistroC010,
	RegistroC100,
	RegistroC110,
	RegistroC111,
	RegistroC120,
	RegistroC170,
	RegistroC175,
	RegistroC180,
	RegistroC181,
	RegistroC185,
	RegistroC188,
	RegistroC190,
	RegistroC191,
	RegistroC195,
	RegistroC198,
	RegistroC199,
	RegistroC380,
	RegistroC381,
	RegistroC385,
	RegistroC395,
	RegistroC396,
	RegistroC400,
	RegistroC405,
	RegistroC481,
	RegistroC485,
	RegistroC489,
	RegistroC490,
	RegistroC491,
	RegistroC495,
	RegistroC499,
	RegistroC500,
	RegistroC501,
	RegistroC505,
	RegistroC509,
	RegistroC600,
	RegistroC601,
	RegistroC605,
	RegistroC609,
	RegistroC800,
	RegistroC810,
	RegistroC820,
	RegistroC830,
	RegistroC860,
	RegistroC870,
	RegistroC880,
	RegistroC890,
	RegistroC990
	
}
