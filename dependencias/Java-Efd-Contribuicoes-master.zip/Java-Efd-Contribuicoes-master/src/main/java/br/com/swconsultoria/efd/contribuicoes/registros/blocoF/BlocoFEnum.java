/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.blocoF;

/**
 * @author Yuri Lemes
 *
 */
public enum BlocoFEnum {

	RegistroF001,
	RegistroF010,
	RegistroF100,
	RegistroF111,
	RegistroF120,
	RegistroF129,
	RegistroF130,
	RegistroF139,
	RegistroF150,
	RegistroF200,
	RegistroF205,
	RegistroF210,
	RegistroF211,
	RegistroF500,
	RegistroF509,
	RegistroF510,
	RegistroF519,
	RegistroF525,
	RegistroF550,
	RegistroF559,
	RegistroF560,
	RegistroF569,
	RegistroF600,
	RegistroF700,
	RegistroF800,
	RegistroF990
	
}
