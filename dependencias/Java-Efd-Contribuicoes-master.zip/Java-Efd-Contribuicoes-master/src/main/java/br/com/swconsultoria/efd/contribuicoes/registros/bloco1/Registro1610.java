/**
 * 
 */
package br.com.swconsultoria.efd.contribuicoes.registros.bloco1;

/**
 * @author Yuri Lemes
 *
 */
public class Registro1610 {

	private final String reg = "1610";
	private String cnpj;
	private String cst_cofins;
	private String cod_part;
	private String dt_oper;
	private String vl_oper;
	private String vl_bc_cofins;
	private String aliq_cofins;
	private String vl_cofins;
	private String cod_cta;
	private String desc_compl;

	/**
	 * @return the cnpj
	 */
	public String getCnpj() {
		return cnpj;
	}

	/**
	 * @param cnpj
	 *            the cnpj to set
	 */
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	/**
	 * @return the cst_cofins
	 */
	public String getCst_cofins() {
		return cst_cofins;
	}

	/**
	 * @param cst_cofins
	 *            the cst_cofins to set
	 */
	public void setCst_cofins(String cst_cofins) {
		this.cst_cofins = cst_cofins;
	}

	/**
	 * @return the cod_part
	 */
	public String getCod_part() {
		return cod_part;
	}

	/**
	 * @param cod_part
	 *            the cod_part to set
	 */
	public void setCod_part(String cod_part) {
		this.cod_part = cod_part;
	}

	/**
	 * @return the dt_oper
	 */
	public String getDt_oper() {
		return dt_oper;
	}

	/**
	 * @param dt_oper
	 *            the dt_oper to set
	 */
	public void setDt_oper(String dt_oper) {
		this.dt_oper = dt_oper;
	}

	/**
	 * @return the vl_oper
	 */
	public String getVl_oper() {
		return vl_oper;
	}

	/**
	 * @param vl_oper
	 *            the vl_oper to set
	 */
	public void setVl_oper(String vl_oper) {
		this.vl_oper = vl_oper;
	}

	/**
	 * @return the vl_bc_cofins
	 */
	public String getVl_bc_cofins() {
		return vl_bc_cofins;
	}

	/**
	 * @param vl_bc_cofins
	 *            the vl_bc_cofins to set
	 */
	public void setVl_bc_cofins(String vl_bc_cofins) {
		this.vl_bc_cofins = vl_bc_cofins;
	}

	/**
	 * @return the aliq_cofins
	 */
	public String getAliq_cofins() {
		return aliq_cofins;
	}

	/**
	 * @param aliq_cofins
	 *            the aliq_cofins to set
	 */
	public void setAliq_cofins(String aliq_cofins) {
		this.aliq_cofins = aliq_cofins;
	}

	/**
	 * @return the vl_cofins
	 */
	public String getVl_cofins() {
		return vl_cofins;
	}

	/**
	 * @param vl_cofins
	 *            the vl_cofins to set
	 */
	public void setVl_cofins(String vl_cofins) {
		this.vl_cofins = vl_cofins;
	}

	/**
	 * @return the cod_cta
	 */
	public String getCod_cta() {
		return cod_cta;
	}

	/**
	 * @param cod_cta
	 *            the cod_cta to set
	 */
	public void setCod_cta(String cod_cta) {
		this.cod_cta = cod_cta;
	}

	/**
	 * @return the desc_compl
	 */
	public String getDesc_compl() {
		return desc_compl;
	}

	/**
	 * @param desc_compl
	 *            the desc_compl to set
	 */
	public void setDesc_compl(String desc_compl) {
		this.desc_compl = desc_compl;
	}

	/**
	 * @return the reg
	 */
	public String getReg() {
		return reg;
	}

}
