# tcpip-stream


You should have local network printer, but you don't need to have  one to run this sample.

You can run  one  server-print instance to make one pipe between soket and local printer, see [server-print](../../miscellaneous/server-print) 


