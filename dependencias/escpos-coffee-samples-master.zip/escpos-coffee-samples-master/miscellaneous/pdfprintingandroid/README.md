# PdfPrintingAndroid

Shows how to print pdf documents on Android

## Points of attention:

### API Level: 21 

### To use espos-coffee lib on android, read [this](../AndroidImage/README.md)

### If you are building a server or desktop application, go to [PdfPrinting](../PdfPrinting) 
