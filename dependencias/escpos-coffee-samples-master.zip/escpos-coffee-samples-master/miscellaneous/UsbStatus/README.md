# UsbStatus


If you want to get status from the usb escpos printer, then take a look at this project.

It uses usb4java library: 


http://usb4java.org/

http://github.com/usb4java/usb4java




## Read this before use
I'm not a usb4java expert, then if you are in trouble with usb4java, probably I'll not help you.

For me, the printer itself have its status led indicator, and its enough.

The escpos-coffee have the PrinterOutputStream that works properly to print.


But if you really want to get online status of the printer, go ahead and have fun.


About my environment: ubuntu and usb Epson-TM-T20. 

I hope that this project can guide you on getting online status printer.


## Screenshots

![output](screenshots/frame1.png?raw=true "frame1")

![output](screenshots/frame2.png?raw=true "frame2")


## Using on Linux
##### 1. Discover  vendorId,  productId,  interfaceNumber, endpointAddressOut and endpointAddressIn

```shell script
lsusb -v
```

```
Bus 001 Device 005: ID 04b8:0e03 Seiko Epson Corp. TM-T20
Device Descriptor:
...
  idVendor           0x04b8 Seiko Epson Corp.
  idProduct          0x0e03 
  bcdDevice            1.00
  iManufacturer           1 EPSON
  iProduct                2 TM-T20
  iSerial                 3 xxxxx
  bNumConfigurations      1
  Configuration Descriptor:
    bLength                 9
    bDescriptorType         2
    wTotalLength       0x0020
    bNumInterfaces          1
    bConfigurationValue     1
    iConfiguration          0 
    bmAttributes         0xc0
      Self Powered
    MaxPower                2mA
    Interface Descriptor:
      bLength                 9
      bDescriptorType         4
      bInterfaceNumber        0
      bAlternateSetting       0
      bNumEndpoints           2
      bInterfaceClass         7 Printer
      bInterfaceSubClass      1 Printer
      bInterfaceProtocol      2 Bidirectional
      iInterface              0 
      Endpoint Descriptor:
        bLength                 7
        bDescriptorType         5
        bEndpointAddress     0x01  EP 1 OUT
        bmAttributes            2
          Transfer Type            Bulk
          Synch Type               None
          Usage Type               Data
        wMaxPacketSize     0x0040  1x 64 bytes
        bInterval               0
      Endpoint Descriptor:
        bLength                 7
        bDescriptorType         5
        bEndpointAddress     0x82  EP 2 IN
        bmAttributes            2
          Transfer Type            Bulk
          Synch Type               None
          Usage Type               Data
        wMaxPacketSize     0x0040  1x 64 bytes
        bInterval               0
```   

##### 2. Configure your usb4java instance
Create the instance of  UsbStatusTMT20 passing the params 
```java
        usbStatus = new UsbStatusTMT20((short) 0x04b8,(short)0x0e03, (byte) 0x00, (byte) 0x01, (byte) 0x82);
```


##### 2. If you want, write your own implementation of UsbStatus
Its not difficult, but you need to get your printer documentation and find something like
"Enables or disables basic ASB" (Automatic Status Back) (GS a n) 

Based on your printer documentation, implement your processData method similar on UsbStatusTMT20.java

Even if your printer is the same of mine (TM-T20), you can customize your processData method for your needs.

Note that all information about status of the printer was produced by processData method. The base class read bytes, and
call this processData always that printer send data by usb interface, 
but you need change the status at this method by calling addError or addInfo, then this function is the most important to understand.

```java 
    /**
     * The method is implemented accordingly of follow lines (documentation)
     * ASB status binary (x=0 or 1)
     * first byte
     * 0xx1 xx00
     * bit 2 = 1: Drawer kick-out connector pin 3: High
     * bit 2 = 0: Drawer kick-out connector pin 3: Low
     * bit 3 = 1: in Offline, 0: in Online
     * bit 5 = 1: Cover is open, 0: closed
     * bit 6 = 1: on feeding paper by switch, 0: not
     *
     * 2nd byte
     * 0xx0 x000
     * bit 3 = 1: Autocutter error, 0: not
     * bit 5 = 1: Unrecoverable error, 0: not
     * bit 6 = 1: Automatically recoverable error, 0: not
     *
     * 3rd byte
     * 0110 xx00
     * bit 2, 3 = 1: Paper end, 0: paper present
     *
     * 4th byte
     * 0110 1111
     *
     * @param data - bytes with status of the printer
     * @param size - size of the byte[] data.
     */
    @Override
    protected void processData(byte[] data, int size){
        // continue if # of bytes received is not multiple of 4
        if (((size % 4) != 0) || size < 4) {
            return;
        }

        int byte3 = data[size - 2];
        int byte2 = data[size - 3];
        int byte1 = data[size - 4];

        mapErrors.clear();
        mapInfo.clear();


        if (bitAndCompare(byte1, bit3)){
            addError(new Status(1,"Offline"));
        }else{
            addInfo(new Status(50, "Online"));
        }
        if (bitAndCompare(byte1, bit5)) addError(new Status(2,"Cover is open"));
        if (bitAndCompare(byte1, bit6)) addError(new Status(3,"Feeding paper by switch"));

        if (bitAndCompare(byte2, bit3)) addError(new Status(4,"Autocutter error"));
        if (bitAndCompare(byte2, bit5)) addError(new Status(5,"Unrecoverable error"));
        if (bitAndCompare(byte2, bit6)) addError(new Status(6,"Automatically recoverable error"));

        if (bitAndCompare(byte3, bit2) || bitAndCompare(byte3, bit3)) addError(new Status(7,"Paper end"));


    }
``` 


##### 3. Configure your events
You can work with usbStatus.getMapErrors(), usbStatus.getMapInfo(), isFinished() and haveAnyError()...

 

```java
        usbStatus.addEventListener(new UsbPrinterEvent() {
            @Override
            public void onStatusChanged() {
                if(usbStatus.haveAnyError()){
                    labelStatus.setBackground(Color.red);
                }else{
                    labelStatus.setBackground(Color.green);
                }
            }
        });

``` 

##### 4. Before the program exit, you need to call finish()
This is necessary to release usb resources
```java
    try {
        usbStatus.finish();
    } catch (UsbException | InterruptedException e) {
        e.printStackTrace();
    }
``` 

##### 5. Compile and run
```shell script
mvn clean package
java -jar  target/Usb4JavaStream-4.0.0-SNAPSHOT-jar-with-dependencies.jar
```
if you have permissions problems, then you can run with sudo...
```shell script
mvn clean package
sudo java -jar target/UsbStatus-4.0.1-jar-with-dependencies.jar
```


