package br.com.swconsultoria.exemploapinfe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploApiNfeApplicationTests {

	@Test
	void contextLoads() {
	}

}
