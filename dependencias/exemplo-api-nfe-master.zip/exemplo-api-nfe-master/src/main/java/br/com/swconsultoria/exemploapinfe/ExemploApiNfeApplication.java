//package br.com.swconsultoria.exemploapinfe;
//
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//@SpringBootApplication
//public class ExemploApiNfeApplication {
//
//	public static void main(String[] args) {
//		SpringApplication.run(ExemploApiNfeApplication.class, args);
//	}
//
//}
