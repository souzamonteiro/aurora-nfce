Vallia
======

Validadores usados no projeto [Lançado embutido, incubado]

[![Build Status](https://ci-jrimum.rhcloud.com/buildStatus/icon?job=Vallia)](https://ci-jrimum.rhcloud.com)
