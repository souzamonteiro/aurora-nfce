Utilix Changelog
=============================

0.2.3 (2014/02/01) suport bopepo-0.2.3
---------------------------------------

**Improvement**

 * #2: Remover classes relacionadas a LineOfFields