Utilix
======

Utilitários usados no projeto [Lançado embutido, incubado]

[![Build Status](https://ci-jrimum.rhcloud.com/buildStatus/icon?job=Utilix)](https://ci-jrimum.rhcloud.com)
