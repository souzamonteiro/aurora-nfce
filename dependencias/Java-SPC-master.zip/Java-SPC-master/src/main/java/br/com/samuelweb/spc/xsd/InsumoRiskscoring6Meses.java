package br.com.samuelweb.spc.xsd;

/**
 * @author Samuel Oliveira - samuk.exe@hotmail.com
 * Data: 01/09/2017 - 10:46
 */
public class InsumoRiskscoring6Meses implements org.apache.axis2.databinding.ADBBean {
        /* This type was generated from the piece of schema that had
           name = Insumo-Riskscoring-6-Meses
           Namespace URI = http://webservice.consulta.spcjava.spcbrasil.org/
           Namespace Prefix = ns1
         */

    /**
     * field for HorizonteTempo
     */
    protected int localHorizonteTempo;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localHorizonteTempoTracker = false;

    /**
     * field for MensagemInterpretacao
     */
    protected java.lang.String localMensagemInterpretacao;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMensagemInterpretacaoTracker = false;

    /**
     * field for MensagemPrinad
     */
    protected java.lang.String localMensagemPrinad;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMensagemPrinadTracker = false;

    /**
     * field for MensagemRiskscoring
     * This was an Array!
     */
    protected MensagemRiskscoring[] localMensagemRiskscoring;

    /*  This tracker boolean wil be used to detect whether the user called the set method
     *   for this attribute. It will be used to determine whether to include this field
     *   in the serialized XML
     */
    protected boolean localMensagemRiskscoringTracker = false;

    /**
     * field for DataFator
     * This was an Attribute!
     */
    protected java.util.Calendar localDataFator;

    /**
     * field for FatorPrinad
     * This was an Attribute!
     */
    protected java.math.BigDecimal localFatorPrinad;

    /**
     * field for FatorRiskscoring
     * This was an Attribute!
     */
    protected java.math.BigDecimal localFatorRiskscoring;

    public boolean isHorizonteTempoSpecified() {
        return localHorizonteTempoTracker;
    }

    /**
     * Auto generated getter method
     * @return int
     */
    public int getHorizonteTempo() {
        return localHorizonteTempo;
    }

    /**
     * Auto generated setter method
     * @param param HorizonteTempo
     */
    public void setHorizonteTempo(int param) {
        // setting primitive attribute tracker to true
        localHorizonteTempoTracker = param != java.lang.Integer.MIN_VALUE;

        this.localHorizonteTempo = param;
    }

    public boolean isMensagemInterpretacaoSpecified() {
        return localMensagemInterpretacaoTracker;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getMensagemInterpretacao() {
        return localMensagemInterpretacao;
    }

    /**
     * Auto generated setter method
     * @param param MensagemInterpretacao
     */
    public void setMensagemInterpretacao(java.lang.String param) {
        localMensagemInterpretacaoTracker = param != null;

        this.localMensagemInterpretacao = param;
    }

    public boolean isMensagemPrinadSpecified() {
        return localMensagemPrinadTracker;
    }

    /**
     * Auto generated getter method
     * @return java.lang.String
     */
    public java.lang.String getMensagemPrinad() {
        return localMensagemPrinad;
    }

    /**
     * Auto generated setter method
     * @param param MensagemPrinad
     */
    public void setMensagemPrinad(java.lang.String param) {
        localMensagemPrinadTracker = param != null;

        this.localMensagemPrinad = param;
    }

    public boolean isMensagemRiskscoringSpecified() {
        return localMensagemRiskscoringTracker;
    }

    /**
     * Auto generated getter method
     * @return MensagemRiskscoring[]
     */
    public MensagemRiskscoring[] getMensagemRiskscoring() {
        return localMensagemRiskscoring;
    }

    /**
     * validate the array for MensagemRiskscoring
     */
    protected void validateMensagemRiskscoring(MensagemRiskscoring[] param) {
    }

    /**
     * Auto generated setter method
     * @param param MensagemRiskscoring
     */
    public void setMensagemRiskscoring(MensagemRiskscoring[] param) {
        validateMensagemRiskscoring(param);

        localMensagemRiskscoringTracker = param != null;

        this.localMensagemRiskscoring = param;
    }

    /**
     * Auto generated add method for the array for convenience
     * @param param MensagemRiskscoring
     */
    public void addMensagemRiskscoring(MensagemRiskscoring param) {
        if (localMensagemRiskscoring == null) {
            localMensagemRiskscoring = new MensagemRiskscoring[] {  };
        }

        //update the setting tracker
        localMensagemRiskscoringTracker = true;

        java.util.List list = org.apache.axis2.databinding.utils.ConverterUtil.toList(localMensagemRiskscoring);
        list.add(param);
        this.localMensagemRiskscoring = (MensagemRiskscoring[]) list.toArray(new MensagemRiskscoring[list.size()]);
    }

    /**
     * Auto generated getter method
     * @return java.util.Calendar
     */
    public java.util.Calendar getDataFator() {
        return localDataFator;
    }

    /**
     * Auto generated setter method
     * @param param DataFator
     */
    public void setDataFator(java.util.Calendar param) {
        this.localDataFator = param;
    }

    /**
     * Auto generated getter method
     * @return java.math.BigDecimal
     */
    public java.math.BigDecimal getFatorPrinad() {
        return localFatorPrinad;
    }

    /**
     * Auto generated setter method
     * @param param FatorPrinad
     */
    public void setFatorPrinad(java.math.BigDecimal param) {
        this.localFatorPrinad = param;
    }

    /**
     * Auto generated getter method
     * @return java.math.BigDecimal
     */
    public java.math.BigDecimal getFatorRiskscoring() {
        return localFatorRiskscoring;
    }

    /**
     * Auto generated setter method
     * @param param FatorRiskscoring
     */
    public void setFatorRiskscoring(java.math.BigDecimal param) {
        this.localFatorRiskscoring = param;
    }

    /**
     *
     * @param parentQName
     * @param factory
     * @return org.apache.axiom.om.OMElement
     */
    public org.apache.axiom.om.OMElement getOMElement(
            final javax.xml.namespace.QName parentQName,
            final org.apache.axiom.om.OMFactory factory)
            throws org.apache.axis2.databinding.ADBException {
        return factory.createOMElement(new org.apache.axis2.databinding.ADBDataSource(
                this, parentQName));
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
                          javax.xml.stream.XMLStreamWriter xmlWriter)
            throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        serialize(parentQName, xmlWriter, false);
    }

    public void serialize(final javax.xml.namespace.QName parentQName,
                          javax.xml.stream.XMLStreamWriter xmlWriter, boolean serializeType)
            throws javax.xml.stream.XMLStreamException,
            org.apache.axis2.databinding.ADBException {
        java.lang.String prefix = null;
        java.lang.String namespace = null;

        prefix = parentQName.getPrefix();
        namespace = parentQName.getNamespaceURI();
        writeStartElement(prefix, namespace, parentQName.getLocalPart(),
                xmlWriter);

        if (serializeType) {
            java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                    "http://webservice.consulta.spcjava.spcbrasil.org/");

            if ((namespacePrefix != null) &&
                    (namespacePrefix.trim().length() > 0)) {
                writeAttribute("xsi",
                        "http://www.w3.org/2001/XMLSchema-instance", "type",
                        namespacePrefix + ":Insumo-Riskscoring-6-Meses",
                        xmlWriter);
            } else {
                writeAttribute("xsi",
                        "http://www.w3.org/2001/XMLSchema-instance", "type",
                        "Insumo-Riskscoring-6-Meses", xmlWriter);
            }
        }

        if (localDataFator != null) {
            writeAttribute("", "data-fator",
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            localDataFator), xmlWriter);
        }

        if (localFatorPrinad != null) {
            writeAttribute("", "fator-prinad",
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            localFatorPrinad), xmlWriter);
        }

        if (localFatorRiskscoring != null) {
            writeAttribute("", "fator-riskscoring",
                    org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            localFatorRiskscoring), xmlWriter);
        }

        if (localHorizonteTempoTracker) {
            namespace = "";
            writeStartElement(null, namespace, "horizonte-tempo", xmlWriter);

            if (localHorizonteTempo == java.lang.Integer.MIN_VALUE) {
                throw new org.apache.axis2.databinding.ADBException(
                        "horizonte-tempo cannot be null!!");
            } else {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        localHorizonteTempo));
            }

            xmlWriter.writeEndElement();
        }

        if (localMensagemInterpretacaoTracker) {
            namespace = "";
            writeStartElement(null, namespace, "mensagem-interpretacao",
                    xmlWriter);

            if (localMensagemInterpretacao == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                        "mensagem-interpretacao cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localMensagemInterpretacao);
            }

            xmlWriter.writeEndElement();
        }

        if (localMensagemPrinadTracker) {
            namespace = "";
            writeStartElement(null, namespace, "mensagem-prinad", xmlWriter);

            if (localMensagemPrinad == null) {
                // write the nil attribute
                throw new org.apache.axis2.databinding.ADBException(
                        "mensagem-prinad cannot be null!!");
            } else {
                xmlWriter.writeCharacters(localMensagemPrinad);
            }

            xmlWriter.writeEndElement();
        }

        if (localMensagemRiskscoringTracker) {
            if (localMensagemRiskscoring != null) {
                for (int i = 0; i < localMensagemRiskscoring.length; i++) {
                    if (localMensagemRiskscoring[i] != null) {
                        localMensagemRiskscoring[i].serialize(new javax.xml.namespace.QName(
                                "", "mensagem-riskscoring"), xmlWriter);
                    } else {
                        // we don't have to do any thing since minOccures is zero
                    }
                }
            } else {
                throw new org.apache.axis2.databinding.ADBException(
                        "mensagem-riskscoring cannot be null!!");
            }
        }

        xmlWriter.writeEndElement();
    }

    private java.lang.String generatePrefix(
            java.lang.String namespace) {
        if (namespace.equals(
                "http://webservice.consulta.spcjava.spcbrasil.org/")) {
            return "ns1";
        }

        return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
    }

    /**
     * Utility method to write an element start tag.
     */
    private void writeStartElement(java.lang.String prefix,
                                   java.lang.String namespace, java.lang.String localPart,
                                   javax.xml.stream.XMLStreamWriter xmlWriter)
            throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeStartElement(writerPrefix, localPart, namespace);
        } else {
            if (namespace.length() == 0) {
                prefix = "";
            } else if (prefix == null) {
                prefix = generatePrefix(namespace);
            }

            xmlWriter.writeStartElement(prefix, localPart, namespace);
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }
    }

    /**
     * Util method to write an attribute with the ns prefix
     */
    private void writeAttribute(java.lang.String prefix,
                                java.lang.String namespace, java.lang.String attName,
                                java.lang.String attValue,
                                javax.xml.stream.XMLStreamWriter xmlWriter)
            throws javax.xml.stream.XMLStreamException {
        java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);

        if (writerPrefix != null) {
            xmlWriter.writeAttribute(writerPrefix, namespace, attName,
                    attValue);
        } else {
            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
            xmlWriter.writeAttribute(prefix, namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeAttribute(java.lang.String namespace,
                                java.lang.String attName, java.lang.String attValue,
                                javax.xml.stream.XMLStreamWriter xmlWriter)
            throws javax.xml.stream.XMLStreamException {
        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attValue);
        } else {
            xmlWriter.writeAttribute(registerPrefix(xmlWriter, namespace),
                    namespace, attName, attValue);
        }
    }

    /**
     * Util method to write an attribute without the ns prefix
     */
    private void writeQNameAttribute(java.lang.String namespace,
                                     java.lang.String attName, javax.xml.namespace.QName qname,
                                     javax.xml.stream.XMLStreamWriter xmlWriter)
            throws javax.xml.stream.XMLStreamException {
        java.lang.String attributeNamespace = qname.getNamespaceURI();
        java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);

        if (attributePrefix == null) {
            attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
        }

        java.lang.String attributeValue;

        if (attributePrefix.trim().length() > 0) {
            attributeValue = attributePrefix + ":" + qname.getLocalPart();
        } else {
            attributeValue = qname.getLocalPart();
        }

        if (namespace.equals("")) {
            xmlWriter.writeAttribute(attName, attributeValue);
        } else {
            registerPrefix(xmlWriter, namespace);
            xmlWriter.writeAttribute(attributePrefix, namespace, attName,
                    attributeValue);
        }
    }

    /**
     *  method to handle Qnames
     */
    private void writeQName(javax.xml.namespace.QName qname,
                            javax.xml.stream.XMLStreamWriter xmlWriter)
            throws javax.xml.stream.XMLStreamException {
        java.lang.String namespaceURI = qname.getNamespaceURI();

        if (namespaceURI != null) {
            java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);

            if (prefix == null) {
                prefix = generatePrefix(namespaceURI);
                xmlWriter.writeNamespace(prefix, namespaceURI);
                xmlWriter.setPrefix(prefix, namespaceURI);
            }

            if (prefix.trim().length() > 0) {
                xmlWriter.writeCharacters(prefix + ":" +
                        org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qname));
            } else {
                // i.e this is the default namespace
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                        qname));
            }
        } else {
            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                    qname));
        }
    }

    private void writeQNames(javax.xml.namespace.QName[] qnames,
                             javax.xml.stream.XMLStreamWriter xmlWriter)
            throws javax.xml.stream.XMLStreamException {
        if (qnames != null) {
            // we have to store this data until last moment since it is not possible to write any
            // namespace data after writing the charactor data
            java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
            java.lang.String namespaceURI = null;
            java.lang.String prefix = null;

            for (int i = 0; i < qnames.length; i++) {
                if (i > 0) {
                    stringToWrite.append(" ");
                }

                namespaceURI = qnames[i].getNamespaceURI();

                if (namespaceURI != null) {
                    prefix = xmlWriter.getPrefix(namespaceURI);

                    if ((prefix == null) || (prefix.length() == 0)) {
                        prefix = generatePrefix(namespaceURI);
                        xmlWriter.writeNamespace(prefix, namespaceURI);
                        xmlWriter.setPrefix(prefix, namespaceURI);
                    }

                    if (prefix.trim().length() > 0) {
                        stringToWrite.append(prefix).append(":")
                                .append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                        qnames[i]));
                    } else {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                                qnames[i]));
                    }
                } else {
                    stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            qnames[i]));
                }
            }

            xmlWriter.writeCharacters(stringToWrite.toString());
        }
    }

    /**
     * Register a namespace prefix
     */
    private java.lang.String registerPrefix(
            javax.xml.stream.XMLStreamWriter xmlWriter,
            java.lang.String namespace)
            throws javax.xml.stream.XMLStreamException {
        java.lang.String prefix = xmlWriter.getPrefix(namespace);

        if (prefix == null) {
            prefix = generatePrefix(namespace);

            javax.xml.namespace.NamespaceContext nsContext = xmlWriter.getNamespaceContext();

            while (true) {
                java.lang.String uri = nsContext.getNamespaceURI(prefix);

                if ((uri == null) || (uri.length() == 0)) {
                    break;
                }

                prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
            }

            xmlWriter.writeNamespace(prefix, namespace);
            xmlWriter.setPrefix(prefix, namespace);
        }

        return prefix;
    }

    /**
     *  Factory class that keeps the parse method
     */
    public static class Factory {
        private org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory.getLog(Factory.class);

        /**
         * static method to create the object
         * Precondition:  If this object is an element, the current or next start element starts this object and any intervening reader events are ignorable
         *                If this object is not an element, it is a complex type and the reader is at the event just after the outer start element
         * Postcondition: If this object is an element, the reader is positioned at its end element
         *                If this object is a complex type, the reader is positioned at the end element of its outer element
         */
        public static InsumoRiskscoring6Meses parse(
                javax.xml.stream.XMLStreamReader reader)
                throws java.lang.Exception {
            InsumoRiskscoring6Meses object = new InsumoRiskscoring6Meses();

            int event;
            javax.xml.namespace.QName currentQName = null;
            java.lang.String nillableValue = null;
            java.lang.String prefix = "";
            java.lang.String namespaceuri = "";

            try {
                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                currentQName = reader.getName();

                if (reader.getAttributeValue(
                        "http://www.w3.org/2001/XMLSchema-instance",
                        "type") != null) {
                    java.lang.String fullTypeName = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "type");

                    if (fullTypeName != null) {
                        java.lang.String nsPrefix = null;

                        if (fullTypeName.indexOf(":") > -1) {
                            nsPrefix = fullTypeName.substring(0,
                                    fullTypeName.indexOf(":"));
                        }

                        nsPrefix = (nsPrefix == null) ? "" : nsPrefix;

                        java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(
                                ":") + 1);

                        if (!"Insumo-Riskscoring-6-Meses".equals(type)) {
                            //find namespace for the prefix
                            java.lang.String nsUri = reader.getNamespaceContext()
                                    .getNamespaceURI(nsPrefix);

                            return (InsumoRiskscoring6Meses) ExtensionMapper.getTypeObject(nsUri,
                                    type, reader);
                        }
                    }
                }

                // Note all attributes that were handled. Used to differ normal attributes
                // from anyAttributes.
                java.util.Vector handledAttributes = new java.util.Vector();

                // handle attribute "data-fator"
                java.lang.String tempAttribDataFator = reader.getAttributeValue(null,
                        "data-fator");

                if (tempAttribDataFator != null) {
                    java.lang.String content = tempAttribDataFator;

                    object.setDataFator(org.apache.axis2.databinding.utils.ConverterUtil.convertToDateTime(
                            tempAttribDataFator));
                } else {
                }

                handledAttributes.add("data-fator");

                // handle attribute "fator-prinad"
                java.lang.String tempAttribFatorPrinad = reader.getAttributeValue(null,
                        "fator-prinad");

                if (tempAttribFatorPrinad != null) {
                    java.lang.String content = tempAttribFatorPrinad;

                    object.setFatorPrinad(org.apache.axis2.databinding.utils.ConverterUtil.convertToDecimal(
                            tempAttribFatorPrinad));
                } else {
                }

                handledAttributes.add("fator-prinad");

                // handle attribute "fator-riskscoring"
                java.lang.String tempAttribFatorRiskscoring = reader.getAttributeValue(null,
                        "fator-riskscoring");

                if (tempAttribFatorRiskscoring != null) {
                    java.lang.String content = tempAttribFatorRiskscoring;

                    object.setFatorRiskscoring(org.apache.axis2.databinding.utils.ConverterUtil.convertToDecimal(
                            tempAttribFatorRiskscoring));
                } else {
                }

                handledAttributes.add("fator-riskscoring");

                reader.next();

                java.util.ArrayList list4 = new java.util.ArrayList();

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName("", "horizonte-tempo").equals(
                                reader.getName())) ||
                        new javax.xml.namespace.QName("", "horizonte-tempo").equals(
                                reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "nil");

                    if ("true".equals(nillableValue) ||
                            "1".equals(nillableValue)) {
                        throw new org.apache.axis2.databinding.ADBException(
                                "The element: " + "horizonte-tempo" +
                                        "  cannot be null");
                    }

                    java.lang.String content = reader.getElementText();

                    object.setHorizonteTempo(org.apache.axis2.databinding.utils.ConverterUtil.convertToInt(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                    object.setHorizonteTempo(java.lang.Integer.MIN_VALUE);
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName("",
                                "mensagem-interpretacao").equals(
                                reader.getName())) ||
                        new javax.xml.namespace.QName("",
                                "mensagem-interpretacao").equals(
                                reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "nil");

                    if ("true".equals(nillableValue) ||
                            "1".equals(nillableValue)) {
                        throw new org.apache.axis2.databinding.ADBException(
                                "The element: " + "mensagem-interpretacao" +
                                        "  cannot be null");
                    }

                    java.lang.String content = reader.getElementText();

                    object.setMensagemInterpretacao(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName("", "mensagem-prinad").equals(
                                reader.getName())) ||
                        new javax.xml.namespace.QName("", "mensagem-prinad").equals(
                                reader.getName())) {
                    nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                            "nil");

                    if ("true".equals(nillableValue) ||
                            "1".equals(nillableValue)) {
                        throw new org.apache.axis2.databinding.ADBException(
                                "The element: " + "mensagem-prinad" +
                                        "  cannot be null");
                    }

                    java.lang.String content = reader.getElementText();

                    object.setMensagemPrinad(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(
                            content));

                    reader.next();
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if ((reader.isStartElement() &&
                        new javax.xml.namespace.QName("",
                                "mensagem-riskscoring").equals(reader.getName())) ||
                        new javax.xml.namespace.QName("",
                                "mensagem-riskscoring").equals(reader.getName())) {
                    // Process the array and step past its final element's end.
                    list4.add(MensagemRiskscoring.Factory.parse(reader));

                    //loop until we find a start element that is not part of this array
                    boolean loopDone4 = false;

                    while (!loopDone4) {
                        // We should be at the end element, but make sure
                        while (!reader.isEndElement())
                            reader.next();

                        // Step out of this element
                        reader.next();

                        // Step to next element event.
                        while (!reader.isStartElement() &&
                                !reader.isEndElement())
                            reader.next();

                        if (reader.isEndElement()) {
                            //two continuous end elements means we are exiting the xml structure
                            loopDone4 = true;
                        } else {
                            if (new javax.xml.namespace.QName("",
                                    "mensagem-riskscoring").equals(
                                    reader.getName())) {
                                list4.add(MensagemRiskscoring.Factory.parse(
                                        reader));
                            } else {
                                loopDone4 = true;
                            }
                        }
                    }

                    // call the converter utility  to convert and set the array
                    object.setMensagemRiskscoring((MensagemRiskscoring[]) org.apache.axis2.databinding.utils.ConverterUtil.convertToArray(
                            MensagemRiskscoring.class, list4));
                } // End of if for expected property start element

                else {
                }

                while (!reader.isStartElement() && !reader.isEndElement())
                    reader.next();

                if (reader.isStartElement()) {
                    // 2 - A start element we are not expecting indicates a trailing invalid property
                    throw new org.apache.axis2.databinding.ADBException(
                            "Unexpected subelement " + reader.getName());
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new java.lang.Exception(e);
            }

            return object;
        }
    } //end of factory class
}

